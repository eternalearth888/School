Madalyn Gort
Lab 01

1. I recieved help on this lab from Colton Kohnke (a friend who took Data Structures last year) 

2. While working on the lab, I had quite a bit of trouble with an overall stratgey of how to read the file, apply the changes, and write the file without accessing null memory and making sure that all the changes were made correctly. I overcame this by asking for help from my instructor and Colton; different/more experienced perspectives helped me complete the assignment.
I also had some troubles with the header format of the ppm file that the program created. I fixed this problem by asking the instructor for help and researching the specific format of the header in ppm files. I didn't realize that they had to be so specific. 

3. Overall, I liked the assignment. I enjoyed the fact that a file was written after each execution so that results from different runs could be compared. One thing that I did not like about the assignment was the negate and flatten color methods. While the methods were simple enough to implement, when simply looking at the resulting image, I wasn't sure if I had done the right thing or not. 