1.Include names of all people who helped/collaborated as per the syllabus.
Zheng Li

2.Decribe the challenges you encountered and how you surmounted them
Why I could not output the data of the .cpp file into the outputfile? 
I changed it. I put this procedure in the .main file. :)
Another problem is the difference between "=" and "==". I spent lots of time to debug my program for figure it out.

3.What did you like/dislike about the assignment.
The reason why I like this assignment is that it is not impossible to me. But it takes me really lots of time...
