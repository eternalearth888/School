#pragma once

class pix{
public:
	pix();
	int red,green,blue;
};
