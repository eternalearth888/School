#include "image_pix.h"

pix::pix() {
	red = 0;
	green = 0;
	blue = 0;
}