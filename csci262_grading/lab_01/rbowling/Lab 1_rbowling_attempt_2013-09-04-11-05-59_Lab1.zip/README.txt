
I've only ever taken java before so this was pretty difficult as far as syntax goes.
I got some clarification on what the lab was wanting us to do on the piazza help board for this class 
I did look at a websitre called www.cplusplus.com. It has a lot of good documentation for c++.