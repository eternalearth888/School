Collaborators:

http://www.cplusplus.com/reference/istream/istream/ignore/ for information about ifstream::ignore to ignore the file identifier.

Challenges:
I didn't run into any major challenges in this project. I couldn't get my program to work at first, but I had only forgotten about the
file identifier, so I had to figure out how to ignore the first line. Next, I realized that the first functions I wrote were only modifying
a third of the image, so I modified my loops to iterate (image_x*3) times to cover the R, G, and B values.

Likes/dislikes:
I thought this was an enjoyable lab overall. It gave me a chance to review some of the C++ concepts I may have gotten a bit rusty on over the summer,
but didn't cause any major headaches. It was also neat to be able to manipulate image data through a pure text interface. I
don't have any complaints at all about the assignment.