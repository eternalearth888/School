1.) N/A
2.) flip_horizontal took some time to work out the details. I ended up working with the array as if it
were divided up into parts of 3 integers each. This allowed me to specifiy the pixel and rgb value. I 
would have preferred to have used a 2D array for this, but I was able to do it with a normal 1D array with 
some extra work on the logic.
3.) Liked: Everything!, programming rocks!
    Disliked: Well, I found it annoying to have to work with some of the constraints required, but it is 
	good practice for when you have to work on existing code and don't want to change everything to add
	one new feature, so I think it is valuable experience, despite how much harder it makes the work.
