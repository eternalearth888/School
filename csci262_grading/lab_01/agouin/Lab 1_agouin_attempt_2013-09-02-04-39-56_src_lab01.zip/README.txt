Lab 01 - Andrew Gouin
1. Collaborators: None, just me :]
2. Using vectors worked a lot better for me instead of arrays for the buffer and image for the vertical flip. Had some memory errors due to wrong indexes (needed -1), but all is working now.
3. I really enjoyed this assignment, cool to work with editing legitimate photos.