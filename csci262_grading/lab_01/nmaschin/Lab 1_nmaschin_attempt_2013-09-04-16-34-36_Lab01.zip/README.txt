People who help/collaborated:
---

The hardest part about this lab was probably coming up with the logic to preform operations on the rows of the picture.  It helped to draw diagrams of small arrays, and then apply that logic to the bigger array that represented a row of the picture.

It was interesting to play with the pixels and see how an algorithm can change the look of a picture.

