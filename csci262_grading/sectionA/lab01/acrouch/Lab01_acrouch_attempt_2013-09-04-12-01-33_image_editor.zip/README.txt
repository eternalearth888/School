Peolpe who helped me with this lab: James Slyby

The challenges I faced in regards to this lab were how to go about transferring the file to a 2D array, especially in
regards to the horizontal flip. JK had to help me a great deal here, and show me examples of how arrays can be manipulated
to work as needed.

I liked how the array affected the actual file and replicated it with the specific changes, and how we could view them.
I disliked the horizontal shift, and I struggled at first in regards to having my program read the file.