#include <iostream>
#include <string>
#include  <fstream>
#include "Image.h"

using namespace std;

int main() {
	// Variables
	image test;
	test.run();


	system("pause");
	return 0;
}



