Ali Khavari
Data Structures Noon Class Fall 2013
Lab 1

1. Challenges and Solutions (and likes/dislikes)

	I encountered quite a few challenges and difficulties in this lab, but
	most of these problems were quickly resolved. One of the first challenges
	was to decide how the program was going to be set up. I began writing the 
	program in main, but as i started working on the functions, I realized that 
	using a class would help to keep my program more organized and would allow for
	functionality that could be anticipated at some other point. I did not have 
	enough time to clean up the program as well as i would have liked, but it 
	runs, and can be easily implemented from main. Id like to go and rewrite 
	parts of the image.run() method in order to streamline the code a bit more.
	I had trouble with the flip horizontal at first, but i just had to fix the 
	looping conditions, and the picture came out in the correct orientation.
	Another challenge was the file I/O. I wasnt sure how to deal with the header
	at first. I had two input loops, one to read the header info, and another 
	to read the body info. I then realized that i could condense them into one
	loop and use a counter to step through the file and have conditions set when 
	the header info finished reading. Id like to learn more about storing/reading data
	efficiently. I enjoyed creating the functions in this assignment, but since I
	had trouble with the I/O, i guess that was a dislike.

Did not work with anyone else