Lab 1 - Program written by: Christen Boyer

1. Collaborators: JK Slyby, Ryan Lake. (I also helped: Nate Anderson, Lee Brininger)

2. Challenges: figuring out the flip horizontal function. I just had to write it out on paper to conceptualize what was going on.

3. Likes/Dislikes: I liked seeing what the different functions did to the original picture and then trying to figure out what exactly happened so I can understand what was happening in my code.