1. Thanks to JK Slyby, Jeremy Alvis, and Keith Hellman.
2. The only real problem I had was I put semicolons in stupid places in my for loops, causing my program to fail. 
That was overcome by talking to the above people.
3. I liked the challenge it presented, and the exploration of the .ppm file type. THere was nothing I really didn't like.