//This file contains basic effects used
#include "string"
#include <iostream>
#ifndef Functions
#define Functions
using namespace std;

int negate(int value, int maxcolor);
int flatten();
int greyscale(int red, int green, int blue);
bool ask(string question);

#endif