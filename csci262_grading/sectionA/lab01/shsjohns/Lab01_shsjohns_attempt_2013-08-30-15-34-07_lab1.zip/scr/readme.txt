People who helped me : Greg Johnson.
I had challenges testing my program with the .ppm documents so i instead copied the format for the ppm into a text document and used that to compare to a new text document.
 i also had trouble at the figuring out how to flip horizontally but i overcame it by fixing my algorithm(accidently added 2 to an integer instead of 1).
i disliked the annoyance of the ppm files fighting me. i did like the user interaction at the end, made it a bit more fun
-Shawn