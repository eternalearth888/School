1-I got help two times from the instructor (JK).

2-I got "access violation error", and I fixed it by defining an 2-D array pointer which points to another 1-D array.

3-The bad part about this lab was that I needed to spend a lot of time to complete my code, but I like the result of it. 