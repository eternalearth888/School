CHALLENGES:
1) Lots of array indexes went out of range. Solved by tediously scrutinizing my code.

2) Finding an effective way to flip the image horizontally. This was solved by creating three different arrays in the flip_horizontal function. Then, I later found that when reading and exporting the file, I wasn't reading all the way to the end of what was being used in the buffer ("3 * width" rather than just "width").

WHAT I LIKED/DISLIKED ABOUT THIS PROJECT
I liked that this project was interesting and provided good practice working with files, and editing images like we did is just an awesome thing to do.

I didn't like that this one assignment probably took me 1/4 the time that I put into my final Programming Concepts project.
