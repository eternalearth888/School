1. Tyler Ferguson, Conor McCandless

2. I was challenged by how to get the ints from the file at first until my friend was able to help me realize
that the file remembers where the last space you read a value from was, so I just had to read all of the
header lines in the.ppm file and then I could just iterate the loops after those were out of the way.
Also, the horizontal flip was challenging because I was trying to flip it with only one temp variable to
no real success, but when I used a second temp it worked fine. Last, I ran into a problem with implementing
the functions into my code with the first way I had the program set up to run, so I had to spread out
the lines which I used to iterate through the .ppm files to get it to work and not run redundently.

3. I though that this was a fantastic assignment. I havent coded since senior year high school and I havent
coded in C++ since this course and it reminded me of every major concept that I learned in AP Comp Sci
with the exception of recursion and introduced me to how they work in C++ to the point where I now feel
comfortable coding for this class.