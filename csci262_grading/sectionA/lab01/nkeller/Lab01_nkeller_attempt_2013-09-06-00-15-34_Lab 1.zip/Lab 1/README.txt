Project: Lab 1
Author: Nathaniel Keller

Collaboraters: None

Challenges: Not many related to the project, the major one was getting the dynamic array to behave properly.

Like/Dislike: No major dislikes, I liked how it was broken down into parts, instead of one lump mass of text.