1. I received help from Stack Overflow in order to understand how to pass an array as a parameter for a function 
(http://stackoverflow.com/questions/3473438/c-return-array-in-a-function).

2. I had trouble getting the correct RGB order for the flip_horizontal function. To get it to work, honestly, 
I just messed around with the number order and went from there. Before messing around, I had tried to write it 
out on a piece of paper, but it still wasn't working the way I expected. I also was a little confused on how to
do numbers 6, 7, 8 on the menu. I sat down and thought about it and was able to figure it out on my own.

3. I really did not like how intensive this assignment was. It took me a while to remember how things worked in
c++. Other than that, this assignment was pretty interesting and got me thinking on a few things.