1. Christian Wert and Garrett Sickles
2. I had problems making functions that called for arrays and I therefore just made a class that held all the variables, arrays, and methods for the ppm file.
I also had troubles getting the flip horizontal method to work. It was difficult picturing which index in my buffer array I needed to call upon in order to switch each pixel but not each individual indexes.
It took some trial and error within a for loop to get it to finally work.
3. I liked this lab assignment because it actually feels applicable. Im not drawing random shapes in open frameworks like in CSCI261 but actually making a program that can copy and alter ppm images.