Richmond Lee Brininger

Christen Boyer, JK Slyby

I encountered many challenges, my first one was reading the files in and out of my program. I ended up getting 
help from Slyby to fix it. I then had the trouble of reading in their yes or no answers, truned out I had them 
labled as bools when they should have been chars. My final problem was getting the flip horizontally to work, I 
ended up getting help from.both Slyby and Christen on that one, it was different because I used a 2D array while 
Christen used a 1D array, but I was able to get it to work in the end.

I liked this assignment as a whole. It re-introduces reading and writing files, creating classes, and manipulating
large amounts of data all at once. WHat I disliked were some of the things visual studio required. I could not get
it to read my files until I inserted them into my labone file in just the right way, and was picky about my data 
types.I also have a class during office hours, which is annoying, but Slyby was able to meet with me at other 
times.