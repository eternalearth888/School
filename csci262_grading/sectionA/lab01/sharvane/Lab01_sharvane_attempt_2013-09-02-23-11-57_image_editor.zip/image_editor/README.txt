PROJECT: Image Editor
DATE: 9/2/2013
CLASS: CSCI262

COLLABORATORS: None

PROBLEMS ENCOUNTERED: The image editor lab was straightforward and detailed nicely in
		      the instructions, consequently, the largest problems that I encountered 
		      were a few missed semicolons of which were solved by adding the missing 
		      semicolons. 

WHAT I LIKED/DISLIKED ABOUT THE ASSIGNMENT: What I liked about this assignment was that it taught us 
					    about the format of a ppm file. I never knew that ppm files
					    had a magic number "p3" or "p6" s the first line to indicate 
					    the type of ppm file. 