
/////////////////////////////////////////////PhotoView///////////////////////////////////////////////////////

/////////////////////////////////////////////by : Zachary Barnum/////////////////////////////////////////////

I worked with no one on this assignment working late into the night every night for the last week on this assignment

I encountered a few issues when approaching this project Part I took me the better part of 20 hours dto figure out and I still didn't get it quite right.

My first problem was using 1 Array to accomplish the buffer, I knew how to do it with more than one but I got all the strings of chars to input and I converted 
them to integers so I could manipulate them which was easier for me. 

I got most of my functions to work and I really wish I could have come to a help session because my problem there, and the reason why I have not implemented the 
functions in the final project is because I was having a hard time wrapping my head around ahow to change each integer of the array in continuum and outputing
a final result. 

The reson my project does not work the way it is supposed to is because I am missing a few key arguements that make it all come together.

It occurred to me about an hour ago how to implement the functions into a new class and use getters and setters within the class to make my
program work correctly, but unfortunately I still had to write this README file and Im just out of time. 

Im not trying to make excuses, rather just trying to portray the things I know I did correctly.

 I completed this project to the best of my abilities and I am proud with only 8 weeks to absorb the information of summer II 
c++, and previously being completely computer illiterate I feel like I have come quite a long way. 

I liked this assignment, it was very frustrating, and I probably took more time away from other classes than I would have liked,
but I feel like I learned a lot about what I can do better next time I code. 

This was a serious challenge for me and I feel like a stronger programmer than I was before but I will definetly need to cut down on my work schedule
so I can make it to some help sessions. 