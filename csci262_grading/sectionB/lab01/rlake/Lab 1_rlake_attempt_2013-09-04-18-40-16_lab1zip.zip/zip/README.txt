Submitted by: Ryan Lake


Worked with (minutly): Christen Boyer



I encounted troubles reading into a buffer line by line. That was resolved

Also, trouble using the swap() function for horiz-flip, never resolved :'[


I liked this project because it got me back in the swing of C++.
however, i wish i had more direction than was given (maybe more hints, or examples on the assignement page)


-Ryan