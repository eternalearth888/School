James Dang
Lab 01
PPM

1. James Dang, Nhat Thanh Tran.
2. Overall the program was straightforward and I didn't have much difficulty. Having the ability to
   open and check the file also aided in fixing my code. The most difficult portion was figuring out
   the flip horizontal. The main problem was trying to keep the rgb together while moving each pixel
   from last to front and front to last.After several attempts of reworking it and trying many methods
   I found out that my function works with other peoples programs but not mine. There must have been
   something wrong with my main. I've compared it with others and found nothing to be wrong. Although
   I didn't want to I declared my program finished as the extra hours puzzling over this single function
   was driving me mad and I didn't particularly want to start my program from scratch.
3. I liked how I can visibly check if I did the program correctly because the outfile could be seen.
   I don't feel that this program has anything I could dislike. It was straightforward and had parts
   that took a long time to figure out but I found it to be quite enjoyable. Even being confounded
   trying to figure out flip horizontal was fun in it's own frustrating way even though I still couldn't
   figure out why it didn't work.