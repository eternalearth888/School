1. I was helped by my professor in office hours and via email.
2. I had trouble opening the file that the user specified. 
   I had a lot of trouble with the flip horizontally function.
3. I disliked the flip horizontally function very much. I liked 
   putting in the menu where the user could specify which
   functions could be used on the picture. I also liked the 
   negative and flatten functions. 