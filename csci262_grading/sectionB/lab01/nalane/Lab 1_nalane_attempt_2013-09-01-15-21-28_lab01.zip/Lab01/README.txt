CREATOR:
Nathaniel Lane

COLLABORATORS:
None. No outside information was required.

CHALLENGES:
I personally tend to have a dificult time mentally figuring out how the ends of a for loop should be handled.
Because this assignment used many, many of those, I struggled in this regard. Further, I found that some of the operations,
such as flipping horizontally, were not as straight forward as I had thought. In that particular situation, I found that 
the best solution was to create a copy of the original data to prevent the creation of a mirrored image.

LIKES/DISLIKES:
I loved being able to create something so cool that has such tangible effects. There was very little I did not like about
it, since this is all new, but not too difficult.