In this folder you will find the following:
	-csci499reflectionsPaper.pdf: This is my reflection paper
	-Code/codeReuse: This directory contains my code for the final project. 
	-Code/chapter6: This directory contains my attempt to correct my code for the Binary Search Tree recursion function
	-finalProejctReflections.txt: This small text document contains a short list of what I did in the codeReuse project
