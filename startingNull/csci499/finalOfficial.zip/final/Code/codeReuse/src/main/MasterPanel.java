package main;

import java.awt.*;
import javax.swing.*;

public class MasterPanel extends JFrame {
	public Image master;
	
	public MasterPanel() {
		
	}
}
