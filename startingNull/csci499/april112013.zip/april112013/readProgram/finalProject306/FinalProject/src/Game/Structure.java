/* Deslis, Shpurik, Hetrick, Combs
 * Last Updated: 12/3/12
 * 
 */
package Game;
import java.awt.Graphics;

public abstract class Structure {
	private int x;
	private int y;
	
	public void draw(Graphics g)  {};
	
}
