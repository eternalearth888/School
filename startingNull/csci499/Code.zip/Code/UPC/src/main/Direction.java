package main;

public enum Direction {
	LEFT_TO_RIGHT, RIGHT_TO_LEFT
};
