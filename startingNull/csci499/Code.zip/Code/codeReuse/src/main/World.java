package main;

import java.awt.*;

import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.util.*;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class World extends JPanel implements Runnable {

	private final int HEIGHT = 400;
	private final int WIDTH = 800;
	private Image background;
	private double dTime = .01;
	private Launcher launcher;
	private ArrayList<Pokemon> targets;
	private ArrayList<Pokeball> projectiles;
	private Thread moveThread;

	public ArrayList<Image> pokemon;
	public BufferedImage pokeball;

	public World() {

		moveThread = new Thread(this);

		projectiles = new ArrayList<Pokeball>();
		launcher = new Launcher(this);
		targets = new ArrayList<Pokemon>();

		// Get the background image
		URL url = getClass().getResource("/images/background.jpg");
		MediaTracker tracker = new MediaTracker(this);
		background = Toolkit.getDefaultToolkit().getImage(url);
		tracker.addImage(background, 0);
		try {
			tracker.waitForID(0);
		} catch (InterruptedException e) {
			return;
		}
		
		// Get the pokeball
//		URL url2 = getClass().getResource("/images/pokeball.png");
//		MediaTracker tracker2 = new MediaTracker(this);
//		pokeball = Toolkit.getDefaultToolkit().getImage(url2);
		BufferedImage in;
		BufferedImage newImage;
		try {
			pokeball = ImageIO.read(new File("/home/earth/Documents/school/spring2013/startingNull/csci499/Code/codeReuse/src/images/pokeball.png"));
			//pokeball = new BufferedImage(in.getWidth(), in.getHeight(), BufferedImage.TYPE_INT_ARGB);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		
//		tracker2.addImage(pokeball, 2);
//		try {
//			tracker2.waitForID(2);
//		} catch (InterruptedException e) {
//			return;
//		}

		// Get the pokemon
		Scanner readPokemon;
		ArrayList<String> addPokemon = new ArrayList<String>();
		try {
			readPokemon = new Scanner(new File("textFiles/pokemon"));
			while (readPokemon.hasNextLine()) {
				addPokemon.add(readPokemon.nextLine());
			}

			readPokemon.close();

		} catch (FileNotFoundException e) {
			System.out
					.println("The source file can't be found or does not exist."
							+ e);
		}

		// Choose a random one from the list
		Random r = new Random();
		String randomString = "";
		ArrayList<String> printPokemon = new ArrayList<String>();
		
		for (int i = 0; i < 8; i++) {
			printPokemon.add(addPokemon.get(r.nextInt(addPokemon.size())));
//			System.out.print(printPokemon);
		}
		
		ArrayList<URL> pokeLocation = new ArrayList<URL>();
		pokemon = new ArrayList<Image>();
				
		for (int j = 0; j < printPokemon.size(); j++) {
			pokeLocation.add(getClass().getResource("/pokemon/" + printPokemon.get(j) + ".png"));
			Image pokemonGrab = Toolkit.getDefaultToolkit().getImage(pokeLocation.get(j));
			pokemon.add(pokemonGrab);
			tracker.addImage(pokemonGrab, j);
	
			try {
				tracker.waitForID(j);
			} catch (InterruptedException e) {
				return;
			}
			
		}
		generateTargets(8); // start with 8 random pokemon

		moveThread.start();
	}

	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		Graphics2D g = (Graphics2D) graphics;

		// Draw the background image before moving the origin
		g.drawImage(background, 0, 0, WIDTH, HEIGHT, null);

		// Change origin to bottom left
		g.scale(1.0, -1.0);
		g.translate(0, -HEIGHT);

		// Draw launcher
		launcher.draw(g);

		// Draw projectiles
		for (Pokeball p : projectiles) {
			p.draw(g);
		}

		// Draw targets
		for (Pokemon t : targets) {
			t.draw(g);
		}
	}

	// Randomly generates non-overlapping targets to the right of the launcher
	public void generateTargets(int numTargets) {

		targets.clear();

		Random rand = new Random();

		ArrayList<Integer> locations = new ArrayList<Integer>();

		for (int i = 0; i < numTargets; i++) {

			int location = rand.nextInt(3 * WIDTH / 4) + WIDTH / 4 - Pokemon.TARGET_SIZE;
			int height = rand.nextInt(HEIGHT / 3) + 50;

			if (!locations.contains(location)) {
				locations.add(location);
				makeTarget(location, height, i);
			}
		}
	}

	// makes target at desired location with desired size
	public void makeTarget(int location, int size, int i) {
		targets.add(new Pokemon(location, size, pokemon.get(i)));
	}

	// checks to see if the projectile collided with any targets in this frame,
	// returns null if it did not hit anything
	// projectiles should be destroyed if its height is less than 0;
	// should probably calculate collisions via the bottom left corner as it
	// will lead
	// utilizes insideofme fn in target
	public void checkCollisions() {

		for (Iterator<Pokeball> it = projectiles.listIterator(); it.hasNext();) {
			Pokeball p = it.next();
			if (p.getyPos() <= 0) {
				it.remove();
			}
		}

		if (!targets.isEmpty()) {
			for (Pokemon t : targets) {
				for (Iterator<Pokeball> it = projectiles.listIterator(); it
						.hasNext();) {
					Pokeball p = it.next();
					if (t.insideOfMe(p) && !t.isHit()) {
						it.remove();
						t.setHit();
					}
				}
			}
		}

		boolean unHit = false;
		for (Pokemon t : targets) {

			if (!t.isHit()) {
				unHit = true;
			}
		}

		if (!unHit && !targets.isEmpty()) {
			JOptionPane.showMessageDialog(this, "YOU WON");
			generateTargets(8);
			// launcher.reset();
		}

	}

	// not exactly elegant but it seems the best way to get the projectile into
	// the world
	public void launch() {
		Pokeball temp = launcher.launch();
		if (temp != null) {
			projectiles.add(temp);
		}
	}

	// iterates through projectiles and moves them
	public void moveProjectiles(double deltaTime) {
		for (Pokeball p : projectiles) {
			p.move(deltaTime);
		}
		checkCollisions();
	}

	public double getDTime() {
		return dTime;
	}

	public Launcher getLauncher() {
		return launcher;
	}

	public ArrayList<Pokemon> getTargets() {
		return targets;
	}

	public ArrayList<Pokeball> getProjectiles() {
		return projectiles;
	}

	public void addProjectile(Pokeball p) {
		projectiles.add(p);
	}

	public void clearTargets() {
		targets.clear();
	}

	@Override
	public void run() {
		while (true) {
			synchronized (moveThread) {
				moveProjectiles(dTime);
				repaint();
				try {
					moveThread.wait((long) (dTime * 300));
				} catch (InterruptedException e) {
					System.out.println("InterruptedException caught");
				}
			}
		}
	}
}
