Image Editor - by Austin Kauffman

1. I did not collaborate with anyone.

2. When programming this, I faced difficulty with making little mistakes.
   I multiplied the column by three to account for all the amount of 
   numbers that would be included.  This was done for loop that went
   through and collected the information from the file and then outputted
   to the new file.  When I made the outer loop for the rows, I also
   multiplied that by three, creating errors when making the new image.
   After some time I finally caught this mistake and was able to create
   an image that was the correct size.  The other issue I had surfaced
   with the functions.  I created all of the functionality inside the
   main, but then when I read through the directions it said they needed
   to be functions, so when I tried to work around this, I had an issue
   with variables.  Finally, I realized that I could declare variables
   globally as well.

3. I liked how challenging this assignment was, but at the same time I
   would like for the directions to be a little more clear with the
   functions.  I was unclear exactly how each function should be
   implemented.  For example, with the extra credit, the random noise
   function was not worded to where I could decipher what it meant, but I
   gave my best guess.
