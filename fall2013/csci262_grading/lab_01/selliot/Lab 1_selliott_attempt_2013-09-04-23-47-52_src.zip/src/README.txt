README

google for a couple syntax problems

major challenges are the horizontal flip and the grey scale
and they were not overcome. the values in the array for one
line at a time didn't seem to keep their values when leaving
a for loop, and could not figure out how to incoperate flip 
and grey inside that for loop. 

creating a funtion in main.cpp failed for me and had to incoperate
the function code into main instead of really using functions.
Not really sure what was being asked by that, whether should 
have used classes or not to have the functions in or what.

It was interesting to see how the ppms changed by doing different
things, but for some of the effects I had no idea how to approach
and that was difficult.