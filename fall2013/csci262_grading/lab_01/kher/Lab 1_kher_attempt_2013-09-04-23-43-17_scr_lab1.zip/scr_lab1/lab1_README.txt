README:

Those individuals who helped me included JK Slyby and the site http://www.cs.swarthmore.edu/~soni/cs35/f12/Labs/lab01.php.

The challenges that I encountered included simplifying my code and creating a working function for the gray scale
and the flip. To simplify my code I relied less on temporary variables and inputted the data straight into the 
array. I also tried to stay as far away from the set parameter of 3000 as I could so that no error could occur. 
To avoid the parameter, I limited the array initially and didn't have to include more code for the 3000. My 
biggest challenge when typing up functions for the gray scale and flip was alloting the values to the correct array
index so that when they were placed in the new file the order came out correctly. To fix this I simplified the 
row to 12 and column to 5. Then I had the code write out the index, value and the order of the values written to 
the new file. I could then follow the order better and view the discrepancies. I then corrected these errors 
and repeated the samething until the order of the values matched the correct order.

I liked that the assignment helped write a code that I could use in a practical way. I also liked that the
functions were simply variations of each other, so I could see how subtle variations modified an entire image.
However, I didn't appreciate the instructions for the lab. I think that the instructions were confusing and from
them I had initially believed that you had to fill in the 3000 indices in the array then read them out which
was not helpful. I think that the two instructors way of explaining the lab, whether through piazza or verbally,
was much more helpful.