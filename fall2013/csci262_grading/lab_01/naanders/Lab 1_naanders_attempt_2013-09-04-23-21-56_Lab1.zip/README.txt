Collaborators: Garrett Wiese and Christen Boyer

The most challenging part of this lab was the horizontal flip.  For the life of me, I couldn't understand how to properly flip the array, and as a result I did not complete that section.
The second most challenging part was ensuring the array functioned properly.  I don't think I got my bounds correct, as it appeared that my array doesn't quite reach the data limit.

I liked that we could see the images and manipulate the images through their pixels. It's an interesting thought, complete images are simply a series of color codes from 0 to 255.