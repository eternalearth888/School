/** Automatically generated file. DO NOT MODIFY */
package edu.mines.rbower.internetaccessdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}