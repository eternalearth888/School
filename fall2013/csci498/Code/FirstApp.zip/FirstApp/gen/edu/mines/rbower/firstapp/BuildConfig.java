/** Automatically generated file. DO NOT MODIFY */
package edu.mines.rbower.firstapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}